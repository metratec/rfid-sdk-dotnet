# Changelog

## 3.1.0

* Pulsar LR special commands added (SetRfMode, SetCustomImpinjSettings, CallImpinjAuthenticationService, SetSession)

## 3.0.0

Metratec rfid device library. For communication and control of Metratec RFID devices.
