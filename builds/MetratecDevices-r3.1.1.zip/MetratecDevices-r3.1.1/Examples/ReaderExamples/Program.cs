﻿using ReaderExamples;

namespace Examples
{
  class UsageExample
  {
    static void Main(string[] args)
    {
      // DeskidIsoExamples.InventoryExample();
      // DeskidIsoExamples.ReadWriteExample();
      // DeskidUhfExamples.InventoryExample();
      // DeskidUhfExamples.ReadWriteExample();
      // PulsarMxExamples.InventoryExample();
      // PulsarMxExamples.ReadWriteExample();
      // QuasarMxExamples.InventoryExample();
      // QuasarMxExamples.ReadWriteExample();
      PulsarLrExamples.InventoryExample();
      // PulsarLrExamples.ReadWriteExample();
      // PulsarLrExamples.CustomImpinjExample();
      
    }
  }

}