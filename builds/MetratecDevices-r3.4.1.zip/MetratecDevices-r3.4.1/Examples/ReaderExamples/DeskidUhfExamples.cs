using System;
using System.Collections.Generic;
using MetraTecDevices;

namespace ReaderExamples
{
  /// <summary>
  /// Examples demonstrating DeskID UHF reader operations for Ultra High Frequency (UHF) RFID tags.
  /// Shows usage of both DeskID_UHF_v2 (AT protocol) and DeskID_UHF (legacy) readers for EPC Gen2 tags.
  /// </summary>
  internal class DeskidUhfExamples
  {
    /// <summary>
    /// Demonstrates basic UHF inventory operations using the newer DeskID_UHF_v2 reader.
    /// Shows how to detect EPC Gen2 tags and handle inventory events with power control.
    /// </summary>
    public static void InventoryExample()
    {
      // Create the reader instance using serial communication (DeskID_UHF_v2 uses AT protocol)
      // Note: Update "/dev/ttyACM0" to match your actual device path (Linux/Mac) or "COM#" for Windows
      String port = "/dev/ttyACM0";
      DeskID_UHF_v2 reader = new DeskID_UHF_v2(port);

      // Subscribe to reader connection status changes (Connected/Disconnected)
      reader.StatusChanged += (s, e) => Console.WriteLine($"{e.Timestamp} Reader status changed to {e.Message} ({e.Status})");

      // Subscribe to inventory events - triggered when tags are detected during continuous scanning
      reader.NewInventory += (s, e) =>
      {
        Console.WriteLine($"{e.Timestamp} New inventory event! {e.Tags.Count} UHF Tag(s) found");
        foreach (UhfTag tag in e.Tags)
        {
          // Display EPC which is the primary identifier for UHF tags
          Console.WriteLine(
            $"  EPC: {tag.EPC}" +
            (!string.IsNullOrEmpty(tag.TID) ? $" | TID: {tag.TID}" : "") +
            (tag.RSSI != null ? $" | RSSI: {tag.RSSI} dBm" : ""));
        }
      };

      // Establish connection to the reader with 2-second timeout
      try
      {
        Console.WriteLine($"Connecting to DeskID_UHF_v2 on port {port}...");
        reader.Connect(2000);
        Console.WriteLine("Connection established!");
      }
      catch (MetratecReaderException e)
      {
        Console.WriteLine($"Cannot connect to reader ({e.Message}). Program exits");
        Console.WriteLine("\nTroubleshooting:");
        Console.WriteLine("- Check USB cable connection");
        Console.WriteLine($"- Verify COM port (currently set to {port})");
        Console.WriteLine("- Ensure DeskID_UHF driver is installed");
        Console.WriteLine("- Check if another application is using the COM port");
        Console.WriteLine("- Verify reader is powered on");
        return;
      }

      try
      {
        // Set reader transmission power (1-20 dBm, higher values = longer range but more interference)
        // Adjust based on your environment and tag distance requirements
        reader.SetPower(5);
        Console.WriteLine("Reader power set to 5 dBm");

        // Configure advanced inventory settings
        InventorySettings invSettings = reader.GetInventorySettings();
        invSettings.WithRssi = true;        // Include signal strength (RSSI) in responses
        invSettings.WithTid = true;         // Include Tag Identifier (TID) for additional tag info
        invSettings.OnlyNewTag = false;     // Report all tags, not just newly detected ones
        reader.SetInventorySettings(invSettings);

        // Perform a single inventory scan to detect currently present tags
        // This also triggers the NewInventory event if listeners are registered
        Console.WriteLine("\nPerforming single inventory scan...");
        List<UhfTag> tags = reader.GetSingleInventory();
        Console.WriteLine($"Current inventory: {tags.Count} UHF Tag(s) found");

        foreach (UhfTag tag in tags)
        {
          Console.WriteLine(
            $"  EPC: {tag.EPC}" +
            (!string.IsNullOrEmpty(tag.TID) ? $" | TID: {tag.TID}" : "") +
            (tag.RSSI != null ? $" | RSSI: {tag.RSSI} dBm" : ""));
        }

        // Start continuous inventory scanning in the background
        Console.WriteLine("Starting continuous inventory scan...");
        reader.StartInventory();
        Console.WriteLine("Continuous inventory scan started - Press any key to stop");
        Console.ReadKey();

        // Stop the continuous scanning
        reader.StopInventory();
        Console.WriteLine("Continuous inventory stopped");
      }
      catch (MetratecReaderException ex)
      {
        Console.WriteLine($"Error during operation: {ex.Message}");
      }
      finally
      {
        // Always disconnect to free resources and close serial port
        if (reader.Connected)
        {
          reader.Disconnect();
          Console.WriteLine("Connection closed");
        }
      }
    }

    /// <summary>
    /// Demonstrates reading and writing user data to UHF tag memory using the legacy DeskID_UHF reader.
    /// Shows how to access the User memory bank of EPC Gen2 tags with proper error handling.
    /// </summary>
    public static void ReadWriteExample()
    {
      // Create the reader instance using serial communication (legacy DeskID_UHF)
      // Note: Update "/dev/ttyACM0" to match your actual device path (Linux/Mac) or "COM#" for Windows
      String port = "/dev/ttyACM0";
      DeskID_UHF_v2 reader = new DeskID_UHF_v2(port);

      // Subscribe to reader connection status changes
      reader.StatusChanged += (s, e) => Console.WriteLine($"{e.Timestamp} Reader status changed to {e.Message} ({e.Status})");

      // Establish connection to the reader with 2-second timeout
      try
      {
        Console.WriteLine($"Connecting to DeskID_UHF on port {port} for read/write operations...");
        reader.Connect(2000);
        Console.WriteLine("Connection established!");
      }
      catch (MetratecReaderException e)
      {
        Console.WriteLine($"Cannot connect to reader ({e.Message}). Program exits");
        Console.WriteLine("\nTroubleshooting:");
        Console.WriteLine("- Check USB cable connection");
        Console.WriteLine("- Verify COM port (currently set to COM8)");
        Console.WriteLine("- Ensure DeskID_UHF driver is installed");
        Console.WriteLine("- Check if another application is using the COM port");
        return;
      }

      try
      {
        // Set reader transmission power for optimal performance
        reader.SetPower(9);
        Console.WriteLine("Reader power set to 9 dBm");

        // Wait for a UHF tag to be placed on the reader
        Console.WriteLine("Please place a UHF tag on the DeskID reader...");
        List<UhfTag> tags;
        int attempts = 0;
        do
        {
          tags = reader.GetSingleInventory();
          if (tags.Count == 0)
          {
            attempts++;
            if (attempts % 5 == 0)
            {
              Console.WriteLine($"No tags found after {attempts} attempts. Continuing to search...");
              Console.WriteLine("Make sure you have a UHF/EPC Gen2 compatible tag");
              Console.WriteLine("Try placing the tag closer to the reader antenna");
            }
            System.Threading.Thread.Sleep(1000);
          }
        } while (tags.Count == 0 && attempts < 30);

        if (tags.Count == 0)
        {
          Console.WriteLine("No tags found after 30 seconds. Please check tag compatibility and placement.");
          return;
        }

        // Use the first detected tag for read/write operations
        UhfTag tag = tags[0];
        Console.WriteLine($"UHF tag found: {tag.EPC}");

        // Attempt to read user data from address 0 in the User memory bank
        // Parameters: address (word offset), length (number of words to read)
        Console.WriteLine("Reading user data from address 0...");
        try
        {
          List<UhfTag> resp = reader.ReadTagUsrData(0, 4, tag.EPC); // Read 4 bytes

          if (resp.Count == 0)
          {
            Console.WriteLine("No tag found during read operation");
          }
          else if (resp[0].HasError)
          {
            Console.WriteLine($"Error reading user data: {resp[0].Message}");
            Console.WriteLine("\nPossible causes:");
            Console.WriteLine("- Tag doesn't support user memory");
            Console.WriteLine("- Access password required");
            Console.WriteLine("- Tag moved out of range during read");
            Console.WriteLine("- Tag orientation changed");
          }
          else
          {
            Console.WriteLine($"Read data from address 0: {resp[0].Data}");
          }
        }
        catch (MetratecReaderException ex)
        {
          Console.WriteLine($"Read operation failed: {ex.Message}");
        }
        finally
        {
          // Reset Reader Mask
          reader.ResetMask();
        }

        // Attempt to write user data to address 0 in the User memory bank
        // Data format: hex string (each pair represents one byte)
        string dataToWrite = "01020304"; // 4 bytes as hex string
        Console.WriteLine($"Writing data '{dataToWrite}' to address 0...");
        try
        {
          List<UhfTag> resp = reader.WriteTagUsrData(0, dataToWrite, tag.EPC);

          if (resp.Count == 0)
          {
            Console.WriteLine("No tag found during write operation");
          }
          else if (resp[0].HasError)
          {
            Console.WriteLine($"Error writing user data: {resp[0].Message}");
            Console.WriteLine("\nPossible causes:");
            Console.WriteLine("- Tag is read-only or write-protected");
            Console.WriteLine("- Access password required");
            Console.WriteLine("- Tag moved out of range during write");
            Console.WriteLine("- Insufficient power for write operation");
            Console.WriteLine("- Tag doesn't support user memory writes");
          }
          else
          {
            Console.WriteLine("Data written successfully!");
          }

          // Verify written data
          Console.WriteLine("Verifying written data...");
          List<UhfTag> verifyResp = reader.ReadTagUsrData(0, 4);
          if (verifyResp.Count > 0 && !verifyResp[0].HasError)
          {
            Console.WriteLine($"Verification read: {verifyResp[0].Data}");
            if (verifyResp[0].Data?.ToUpper() == dataToWrite.ToUpper())
            {
              Console.WriteLine("Data verification successful!");
            }
            else
            {
              Console.WriteLine("Data mismatch - write may have failed");
            }
          }
        }
        catch (MetratecReaderException ex)
        {
          Console.WriteLine($"Write operation failed: {ex.Message}");
        }
      }
      catch (MetratecReaderException ex)
      {
        Console.WriteLine($"General reader error: {ex.Message}");
      }
      finally
      {
        // Always disconnect to free resources
        if (reader.Connected)
        {
          reader.Disconnect();
          Console.WriteLine("Connection closed");
        }
      }
    }

  }
}